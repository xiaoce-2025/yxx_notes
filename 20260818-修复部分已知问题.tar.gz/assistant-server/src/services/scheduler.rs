use crate::app_state::AppState;

pub fn start_wechat_listener_scheduler(_state: AppState) {
    // Scheduler disabled for file-based storage
}
